package com.clinica.clinicav2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clinicav2Application {

    public static void main(String[] args) {
        SpringApplication.run(Clinicav2Application.class, args);
    }

}
