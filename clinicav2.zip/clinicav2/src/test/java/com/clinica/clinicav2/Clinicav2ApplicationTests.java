package com.clinica.clinicav2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clinicav2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
